﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using StudentManagement.Models;

namespace StudentManagement.Data.Configurations
{
    public class CourseConfiguration : IEntityTypeConfiguration<Course>
    {
        public void Configure(EntityTypeBuilder<Course> builder)
        {
            builder.HasKey(c => c.CourseId);
            builder.Property(c => c.Title).IsRequired().HasMaxLength(200);
            builder.HasMany(c => c.Enrollments)
                .WithOne(c => c.Course)
                .HasForeignKey(e  => e.CourseId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    
    
    }
}
