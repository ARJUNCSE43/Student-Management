﻿using StudentManagement.Models;

namespace StudentManagement.Repositories
{
    public interface IEnrollmentRepository : IRepository<Enrollment>
    {
        Task<IEnumerable<Enrollment>> GetCourseEnrollmentsAsync(int courseId);

    }
   

}
