﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using StudentManagement.Data;
using StudentManagement.Models;

namespace StudentManagement.Repositories
{

    public class StudentRepository : BaseRepository<Student>, IStudentRepository
    {
        public StudentRepository(AppDbContext context) : base(context) { }
         
       public async Task<Student?> GetStudentDetailsByIdAsync(int id)
        {
            return await _dbSet
                    .Include(s => s.Profile)
                    .Include(s => s.Enrollments)
                    .ThenInclude(e => e.Course)
                    .FirstOrDefaultAsync(s => s.Id == id);

        }
        public override async Task<Student> GetByIdAsync(int id)
        {
            return await _dbSet
                .Include(s => s.Profile)
                .FirstAsync(s => s.Id == id);
        }

    }

}
